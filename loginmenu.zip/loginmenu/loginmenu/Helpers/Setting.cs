﻿using System;
using System.Collections.Generic;
using System.Text;

namespace loginmenu.Helpers
{
    class Setting
    {
    }
}
