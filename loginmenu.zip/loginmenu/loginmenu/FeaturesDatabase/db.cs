﻿namespace loginmenu.FeaturesDatabase
{
    public class db
    {
    }
}