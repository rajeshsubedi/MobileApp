﻿namespace loginmenu.Droid
{
    public class bundle
    {
    }
}