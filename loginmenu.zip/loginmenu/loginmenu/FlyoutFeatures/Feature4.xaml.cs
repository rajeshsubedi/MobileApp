﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using loginmenu;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace loginmenu
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Feature4 : ContentPage
    {
        public Feature4()
        {
            InitializeComponent();
        }
    }
}