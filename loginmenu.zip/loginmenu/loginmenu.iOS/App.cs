﻿namespace loginmenu.iOS
{
    internal class App : Xamarin.Forms.Application
    {
    }
}